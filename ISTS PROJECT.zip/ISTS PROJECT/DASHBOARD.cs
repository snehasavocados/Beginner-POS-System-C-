﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ROCK_STAR_ENTERTAINMENT
{
    public partial class DASHBOARD : Form
    {
        public DASHBOARD()
        {
            InitializeComponent();
        }

        private void DASHBOARD_Load(object sender, EventArgs e)
        {

        }

        private void products_Click(object sender, EventArgs e) // takes you to where you can amke a sale
        {
            SELLING SELL = new SELLING();
            SELL.Show();
            this.Hide();
        }

        private void stock_Click(object sender, EventArgs e) // dashboard takes you to view stock
        {
            ViewStock viewStock = new ViewStock();
            viewStock.Show();
            this.Hide();
        }

        private void logout_Click(object sender, EventArgs e)// Takes you back to login
        {
            LOGIN login = new LOGIN();
            login.Show();
            this.Hide();
                
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ADDPRODUCTS add = new ADDPRODUCTS();
            add.Show();
            this.Hide();
        }
    }
}
