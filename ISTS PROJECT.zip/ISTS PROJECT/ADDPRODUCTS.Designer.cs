﻿
namespace ROCK_STAR_ENTERTAINMENT
{
    partial class ADDPRODUCTS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.ADD = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.ProductPricetb = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CategoryCB = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.GroupCB = new System.Windows.Forms.ComboBox();
            this.ProductQuantitytb = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ProductNametb = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.HotPink;
            this.label1.Location = new System.Drawing.Point(167, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(152, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD PRODUCT ";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.ADD);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.ProductPricetb);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.CategoryCB);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.GroupCB);
            this.panel1.Controls.Add(this.ProductQuantitytb);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.ProductNametb);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(12, 111);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(574, 442);
            this.panel1.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.HotPink;
            this.button1.Location = new System.Drawing.Point(293, 365);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 32);
            this.button1.TabIndex = 11;
            this.button1.Text = "RESET";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ADD
            // 
            this.ADD.BackColor = System.Drawing.Color.Pink;
            this.ADD.Location = new System.Drawing.Point(71, 365);
            this.ADD.Name = "ADD";
            this.ADD.Size = new System.Drawing.Size(136, 32);
            this.ADD.TabIndex = 10;
            this.ADD.Text = "ADD";
            this.ADD.UseVisualStyleBackColor = false;
            this.ADD.Click += new System.EventHandler(this.logout_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.HotPink;
            this.label7.Location = new System.Drawing.Point(215, 260);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(102, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "Product Price";
            // 
            // ProductPricetb
            // 
            this.ProductPricetb.Location = new System.Drawing.Point(185, 308);
            this.ProductPricetb.Name = "ProductPricetb";
            this.ProductPricetb.Size = new System.Drawing.Size(165, 20);
            this.ProductPricetb.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.HotPink;
            this.label6.Location = new System.Drawing.Point(300, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 20);
            this.label6.TabIndex = 7;
            this.label6.Text = "Category";
            // 
            // CategoryCB
            // 
            this.CategoryCB.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CategoryCB.FormattingEnabled = true;
            this.CategoryCB.Items.AddRange(new object[] {
            "ALBUMS",
            "LIGHT STICKS"});
            this.CategoryCB.Location = new System.Drawing.Point(304, 190);
            this.CategoryCB.Name = "CategoryCB";
            this.CategoryCB.Size = new System.Drawing.Size(165, 25);
            this.CategoryCB.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.HotPink;
            this.label5.Location = new System.Drawing.Point(36, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 20);
            this.label5.TabIndex = 5;
            this.label5.Text = "Group";
            // 
            // GroupCB
            // 
            this.GroupCB.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupCB.FormattingEnabled = true;
            this.GroupCB.Items.AddRange(new object[] {
            "AESPA",
            "ATEEZ",
            "BTS",
            "BLACKPINK",
            "CRAVITY",
            "DPR LIVE",
            "ENHYPEN",
            "FIFTY FIFTY",
            "GOT7",
            "G-IDLE",
            "ILLIT",
            "KISS OF LIFE",
            "LE SSERAFIM",
            "MONSTA X",
            "NEW JEANS",
            "NCT",
            "NEW JEANS",
            "RIIZEE",
            "STRAY KIDS"});
            this.GroupCB.Location = new System.Drawing.Point(36, 190);
            this.GroupCB.Name = "GroupCB";
            this.GroupCB.Size = new System.Drawing.Size(165, 25);
            this.GroupCB.TabIndex = 4;
            // 
            // ProductQuantitytb
            // 
            this.ProductQuantitytb.Location = new System.Drawing.Point(304, 104);
            this.ProductQuantitytb.Name = "ProductQuantitytb";
            this.ProductQuantitytb.Size = new System.Drawing.Size(165, 20);
            this.ProductQuantitytb.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.HotPink;
            this.label4.Location = new System.Drawing.Point(300, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "Product Quantity";
            // 
            // ProductNametb
            // 
            this.ProductNametb.Location = new System.Drawing.Point(36, 104);
            this.ProductNametb.Name = "ProductNametb";
            this.ProductNametb.Size = new System.Drawing.Size(165, 20);
            this.ProductNametb.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.HotPink;
            this.label3.Location = new System.Drawing.Point(36, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Product Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.HotPink;
            this.label2.Location = new System.Drawing.Point(449, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "LOGOUT";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.HotPink;
            this.label8.Location = new System.Drawing.Point(603, 521);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(129, 25);
            this.label8.TabIndex = 6;
            this.label8.Text = "ISTS AND CO";
            // 
            // ADDPRODUCTS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(767, 561);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ADDPRODUCTS";
            this.Text = "PRODUCTS";
            this.Load += new System.EventHandler(this.ADDPRODUCTS_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox ProductPricetb;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox CategoryCB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox GroupCB;
        private System.Windows.Forms.TextBox ProductQuantitytb;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ProductNametb;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button ADD;
    }
}