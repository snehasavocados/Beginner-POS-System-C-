﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ROCK_STAR_ENTERTAINMENT
{
    public partial class ViewStock : Form
    {
        public ViewStock()
        {
            InitializeComponent();
        }
        Operations Op = new Operations();
        string myquery;
        private void GetProduct()
        {
            myquery = "select * from Producttbl";
            var ds = Op.populate(myquery);
            DataGridView1.DataSource = ds.Tables[0];
        }
        private void ViewStock_Load(object sender, EventArgs e) //Display data from database in Datagridview
        {
            GetProduct(); 
        }

        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
           
        {
            try
            {


                ProductID.Text = DataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                ProdNameTb.Text = DataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                ProdGroupCb.SelectedItem = DataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                ProdCategoryCb.SelectedItem = DataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                ProdQtyTb.Text = DataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                ProductPriceTb.Text = DataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        private void clear()
        {
            ProductID.Text = "";
            ProdNameTb.Text = "";
            ProdGroupCb.SelectedIndex = -1;
            ProdCategoryCb.SelectedIndex = -1;
            ProdQtyTb.Text = "";
            ProductPriceTb.Text = "";


        }
        
        private void button2_Click(object sender, EventArgs e)// delete products
        {
            try
            {
               myquery = " Delete from Producttbl where ID= "+ProductID.Text+";";
                Op.deleteProd(myquery);
                GetProduct();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)// reset button to clear sny mistakes
        {
            clear();
        }

        private void logout_Click(object sender, EventArgs e)
        {
            try
            {
                myquery = "Update  Producttbl set ProdName= '" + ProdNameTb.Text + "',ProdGroup= '" + ProdGroupCb.SelectedItem.ToString() + "', ProdCat ='" + ProdCategoryCb.SelectedItem.ToString() + ", ProdQty =" + ProdQtyTb.Text + ",ProdPrice=" + ProductPriceTb.Text + "where ID =" + ProductID.Text + "'";
                Op.Editdata(myquery);
                GetProduct();
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            LOGIN login = new LOGIN();
            login.Show();
            this.Hide();
        }

        private void Update_Click(object sender, EventArgs e)
        {
           
            }
        }
    }

