﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ROCK_STAR_ENTERTAINMENT
{
    public partial class LOGIN : Form
    {
        public LOGIN()
        {
            InitializeComponent();
        }

        private void LOGIN_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                MessageBox.Show("Enter Admin name and Password");
            }
            else if (textBox1.Text == "Admin" && textBox2.Text == "Pass")
            {
                DASHBOARD main = new DASHBOARD();
                main.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong Admin Name or Password");
            }
        }

        private void button2_Click(object sender, EventArgs e) // EXIT APPLICATION
        {
            Application.Exit();
        }
    }
}
