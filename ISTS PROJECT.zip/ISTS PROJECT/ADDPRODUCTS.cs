﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ROCK_STAR_ENTERTAINMENT
{
    public partial class ADDPRODUCTS : Form
    {
        public ADDPRODUCTS()
        {
            InitializeComponent();
        }

        private void ADDPRODUCTS_Load(object sender, EventArgs e)
        {

        }
        Operations Op = new Operations();
        string query;
        int ProductID;
        private void logout_Click(object sender, EventArgs e)// Button adds a product 
        {
            try
            {
                ProductID = Op.count();

                query = "Insert into Producttbl values("+ProductID+",'" + ProductNametb.Text + "','" + GroupCB.SelectedItem.ToString()+"','" +CategoryCB.SelectedItem.ToString() + "'," + ProductQuantitytb.Text + "," + ProductPricetb.Text +")";
                Op.insertdata(query);
            }catch(Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            LOGIN login = new LOGIN();
            login.Show();
            this.Hide();
        }
    }
}
