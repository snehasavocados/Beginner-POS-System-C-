﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ROCK_STAR_ENTERTAINMENT
{
    public partial class SELLING : Form
    {
        public SELLING()
        {
            InitializeComponent();
        }
        private void GetProduct()
        {
            string myquery = "select * from Producttbl";
            var ds = Op.populate(myquery);
            DataGridView1.DataSource = ds.Tables[0];
        }
        private void SELLING_Load(object sender, EventArgs e)
        {
            GetProduct();
        }

        
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        Operations Op = new Operations();
        int oldQty = 0;
        int Pid;
        private void DataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
            ProdNameTb.Text = DataGridView1.SelectedRows[0].Cells[1].Value.ToString();
            //ProdQtyTb.Text = DataGridView1.SelectedRows[0].Cells[4].Value.ToString();
            ProdPriceTb.Text = DataGridView1.SelectedRows[0].Cells[5].Value.ToString();
            PRODID.Text = DataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            oldQty = Convert.ToInt32(DataGridView1.SelectedRows[0].Cells[4].Value.ToString());
            Pid = Convert.ToInt32(DataGridView1.SelectedRows[0].Cells[0].Value.ToString());
        }
        int GrdTotal = 0;
        
        private void ADDTOBILL_Click(object sender, EventArgs e)// Add items to your bill
        {
            int n = 0;
            
            int total = Convert.ToInt32(ProdQtyTb.Text) * Convert.ToInt32(ProdPriceTb.Text);
            DataGridViewRow newRow = new DataGridViewRow();
            newRow.CreateCells(BILLDGV);
            newRow.Cells[0].Value = n + 1;
            newRow.Cells[1].Value = ProdNameTb.Text;
            newRow.Cells[2].Value = ProdQtyTb.Text;
            newRow.Cells[3].Value = ProdPriceTb.Text;
            newRow.Cells[4].Value = total;
            BILLDGV.Rows.Add(newRow);
            GrdTotal = GrdTotal + total;
            amount.Text = "" + GrdTotal;

        }
        
  
        

        
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }
       
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
         
        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            LOGIN login = new LOGIN();
            login.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
