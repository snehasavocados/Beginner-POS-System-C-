﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ROCK_STAR_ENTERTAINMENT
{
    class Operations
    {
       protected OleDbConnection getCon()
        {
            OleDbConnection Con = new OleDbConnection();
            Con.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Sinegugu\Desktop\pos1.mdb";
            return Con;
        }
        public void insertdata(string query)// Method to insert data into database
        {
            OleDbConnection Con = getCon();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = Con;
            Con.Open();
            Cmd.CommandText = query;
            Cmd.ExecuteNonQuery();
            MessageBox.Show("Product Addedd Successfully");
            Con.Close();
        }

        public int count() // Generates automatically the ID of the Products
        {
            OleDbConnection Con = getCon();
                string query = "select * from Producttbl order by ID";

            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = Con;
            Con.Open();
            cmd.CommandText = query;

            OleDbDataReader rdr = cmd.ExecuteReader();
            int id = 0;
            while (rdr.Read())
            {
                id = rdr.GetInt32(0);
            }
            id = id + 1;
            Con.Close();
            return id;


        }
        public void Editdata(string query)// Method to insert data into database
        {
            OleDbConnection Con = getCon();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = Con;
            Con.Open();
            Cmd.CommandText = query;
            Cmd.ExecuteNonQuery();
            MessageBox.Show("Product Updated Successfully");
            Con.Close();
        }
            public void deleteProd(string query) //Method to delete data from the database
        {
            OleDbConnection Con = getCon();
            OleDbCommand Cmd = new OleDbCommand();
            Cmd.Connection = Con;
            Con.Open();
            Cmd.CommandText = query;
            Cmd.ExecuteNonQuery();
            MessageBox.Show("Product Deleted Successfully");
            Con.Close();
        }
        // Method to display data in the datagridview

        public DataSet populate(string query)
        {
            OleDbConnection Con = getCon();
            OleDbCommand cmd = new OleDbCommand();
            cmd.Connection = Con;
            cmd.CommandText = query;
            OleDbDataAdapter da = new OleDbDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

           
        }

        



    }
}
